import javax.swing.*;
import java.awt.*;
import java.util.Stack;

public class BorrowedBookListDisplay {
    private JFrame frame;
    private Stack<Library.Book> borrowedBooks;

    public BorrowedBookListDisplay(Stack<Library.Book> borrowedBooks) {
        this.borrowedBooks = borrowedBooks;
    }

    public void display() {
        frame = new JFrame("Borrowed Books");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 300); // Adjust size as needed

        JPanel mainPanel = new JPanel(new GridLayout(0, 1)); // Vertical layout

        if (borrowedBooks.isEmpty()) {
            mainPanel.add(new JLabel("No books currently borrowed."));
        } else {
            for (Library.Book book : borrowedBooks) {
                mainPanel.add(createBookPanel(book));
            }
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        frame.add(scrollPane);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    private JPanel createBookPanel(Library.Book book) {
        JPanel bookPanel = new JPanel(); // Create JPanel first
        bookPanel.setLayout(new BoxLayout(bookPanel, BoxLayout.Y_AXIS)); // Then set BoxLayout
        bookPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding

        bookPanel.add(new JLabel("Title: " + book.getTitle()));
        bookPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Small vertical space
        bookPanel.add(new JLabel("Author: " + book.getAuthor()));
        bookPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Small vertical space
        bookPanel.add(new JLabel("ISBN: " + book.getIsbn()));
        bookPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Larger space between books

        return bookPanel;
    }
}
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Stack;

public class Library {

    private JFrame frame;
    private JPanel panel;
    private JTextArea outputArea;
    private LinkedList<Book> bookList = new LinkedList<>();
    private HashMap<String, Book> bookMap = new HashMap<>();
    private Stack<Book> borrowedBooks = new Stack<>();
    private JButton addBookButton, borrowBookButton, returnBookButton, searchBookButton,
            displayAllBooksButton, displayBorrowedBooksButton;


    public Library() {
        frame = new JFrame("Librofy: A Modern Book Borrowing System Java Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        panel = new JPanel(new BorderLayout());
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        panel.add(scrollPane, BorderLayout.CENTER);


        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        addBookButton = new JButton("Add Book");
        borrowBookButton = new JButton("Borrow Book");
        returnBookButton = new JButton("Return Book");
        searchBookButton = new JButton("Search Book");
        displayAllBooksButton = new JButton("Display All Books");
        displayBorrowedBooksButton = new JButton("Display Borrowed Books");

        buttonPanel.add(addBookButton);
        buttonPanel.add(borrowBookButton);
        buttonPanel.add(returnBookButton);
        buttonPanel.add(searchBookButton);
        buttonPanel.add(displayAllBooksButton);
        buttonPanel.add(displayBorrowedBooksButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);


        addBookButton.addActionListener(e -> addBook());
        borrowBookButton.addActionListener(e -> borrowBook());
        returnBookButton.addActionListener(e -> returnBook());
        searchBookButton.addActionListener(e -> searchBook());
        displayAllBooksButton.addActionListener(e -> displayAllBooks());
        displayBorrowedBooksButton.addActionListener(e -> displayBorrowedBooks());
    }


    public static class Book {
        private String title;
        private String author;
        private String isbn;
        private boolean borrowed;

        public Book(String title, String author, String isbn) {
            this.title = title;
            this.author = author;
            this.isbn = isbn;
            this.borrowed = false;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        public String getIsbn() {
            return isbn;
        }

        public boolean isBorrowed() {
            return borrowed;
        }

        public void setBorrowed(boolean borrowed) {
            this.borrowed = borrowed;
        }
    }

    private void addBook() {
        String title = JOptionPane.showInputDialog(frame, "Enter book title:");
        String author = JOptionPane.showInputDialog(frame, "Enter author:");
        String isbn = JOptionPane.showInputDialog(frame, "Enter ISBN:");

        if (title != null && author != null && isbn != null) {
            Book newBook = new Book(title, author, isbn);
            bookList.add(newBook);
            bookMap.put(newBook.getTitle(), newBook);
            outputArea.append("Book added successfully!\n");
        } else {
            outputArea.append("Add operation cancelled.\n");
        }
    }

    private Book findBookByTitle(String title) {
        return bookMap.get(title);
    }
    private void borrowBook() {
        String title = JOptionPane.showInputDialog(frame, "Enter book title to borrow:");
        if (title != null) {
            Book bookToBorrow = findBookByTitle(title);
            if (bookToBorrow != null) {
                if (!bookToBorrow.isBorrowed()) {
                    bookToBorrow.setBorrowed(true);
                    borrowedBooks.push(bookToBorrow);
                    outputArea.append("Book borrowed successfully!\n");
                } else {
                    outputArea.append("This book is already borrowed.\n");
                }
            } else {
                outputArea.append("Book not found.\n");
            }
        } else {
            outputArea.append("Borrow operation cancelled.\n");
        }
    }

    private void returnBook() {
        String title = JOptionPane.showInputDialog(frame, "Enter book title to return:");
        if (title != null) {
            if (!borrowedBooks.isEmpty()) {
                Book topBook = borrowedBooks.pop();
                if (topBook.getTitle().equalsIgnoreCase(title)) {
                    topBook.setBorrowed(false);
                    outputArea.append("Book returned successfully!\n");
                } else {
                    borrowedBooks.push(topBook);
                    outputArea.append("Incorrect book returned. Please return the most recently borrowed book.\n");
                }
            } else {
                outputArea.append("No books currently borrowed.\n");
            }
        } else {
            outputArea.append("Return operation cancelled.\n");
        }
    }

    private void displayAllBooks() {
        new BookListDisplay(bookList).display();
    }

    private void displayBorrowedBooks() {
        new BorrowedBookListDisplay(borrowedBooks).display();
    }

    private void searchBook() {
        new BookSearch(this).search();
    }

    public LinkedList<Book> getBookList() {
        return bookList;
    }

    public Stack<Book> getBorrowedBooks() {
        return borrowedBooks;
    }
}
import javax.swing.*;
import java.awt.*;

public class BookSearch {
    private Library library;

    public BookSearch(Library library) {
        this.library = library;
    }

    public void search() {
        String searchTerm = JOptionPane.showInputDialog(null, "Enter search term (title, author, or ISBN):", "Book Search", JOptionPane.QUESTION_MESSAGE);
        if (searchTerm == null || searchTerm.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Search cancelled.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
            return; //added return to exit if search is cancelled
        }

        Library.Book foundBook = findBook(searchTerm);

        if (foundBook != null) {
            JFrame resultFrame = new JFrame("Search Result");
            resultFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            resultFrame.setSize(300, 200);
            resultFrame.setLocationRelativeTo(null);

            JPanel contentPanel = new JPanel(new GridLayout(4, 1));
            contentPanel.add(new JLabel("Title: " + foundBook.getTitle()));
            contentPanel.add(new JLabel("Author: " + foundBook.getAuthor()));
            contentPanel.add(new JLabel("ISBN: " + foundBook.getIsbn()));
            contentPanel.add(new JLabel("Borrowed: " + (foundBook.isBorrowed() ? "Yes" : "No")));

            resultFrame.add(contentPanel);
            resultFrame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Book not found.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private Library.Book findBook(String searchTerm) {
        if (library == null || library.getBookList() == null) return null; //added null check
        for (Library.Book book : library.getBookList()) {
            if (book.getTitle().equalsIgnoreCase(searchTerm) ||
                    book.getAuthor().equalsIgnoreCase(searchTerm) ||
                    book.getIsbn().equalsIgnoreCase(searchTerm)) {
                return book;
            }
        }
        return null;
    }
}
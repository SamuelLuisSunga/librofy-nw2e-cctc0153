import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;

public class BookListDisplay {
    private JFrame frame;
    private LinkedList<Library.Book> bookList;

    public BookListDisplay(LinkedList<Library.Book> bookList) {
        this.bookList = bookList;
    }

    public void display() {
        frame = new JFrame("All Books");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 300); // Adjust size as needed

        JPanel mainPanel = new JPanel(new GridLayout(0, 1)); // Vertical layout

        if (bookList.isEmpty()) {
            mainPanel.add(new JLabel("No books in the library."));
        } else {
            for (Library.Book book : bookList) {
                mainPanel.add(createBookPanel(book));
            }
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        frame.add(scrollPane);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    private JPanel createBookPanel(Library.Book book) {
        JPanel bookPanel = new JPanel(); // Create JPanel first
        bookPanel.setLayout(new BoxLayout(bookPanel, BoxLayout.Y_AXIS)); // Then set BoxLayout
        bookPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding around each book

        bookPanel.add(new JLabel("Title: " + book.getTitle()));
        bookPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Small vertical space
        bookPanel.add(new JLabel("Author: " + book.getAuthor()));
        bookPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Small vertical space
        bookPanel.add(new JLabel("ISBN: " + book.getIsbn()));
        bookPanel.add(Box.createRigidArea(new Dimension(0, 5))); // Small vertical space
        bookPanel.add(new JLabel("Borrowed: " + (book.isBorrowed() ? "Yes" : "No")));
        bookPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Larger space between books

        return bookPanel;
    }
}